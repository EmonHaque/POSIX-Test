#include "BlockingQueue.h"
#include <malloc.h>
#include <unistd.h>

void putInto(BlockingQueue *queue, void *item) {
    pthread_mutex_lock(&queue->lock);
    void **items = queue->items;
    items[queue->count++] = item;
    if (queue->count == queue->capacity) {
        queue->capacity *= 2;
        queue->items = realloc(queue->items, queue->capacity * sizeof(void *));
    }
    if (queue->isWaiting) {
        pthread_cond_signal(&queue->condition);
    }
    pthread_mutex_unlock(&queue->lock);
}

void *takeOutFrom(BlockingQueue *queue) {
    void *item = 0;
    pthread_mutex_lock(&queue->lock);
    if (queue->count > 0) {
        void **items = queue->items;
        item = items[0];
    } else {
        queue->isWaiting = 1;
        pthread_cond_wait(&queue->condition, &queue->lock);
        queue->isWaiting = 0;
        void **items = queue->items;
        item = items[0];
    }
    queue->count--;
    pthread_mutex_unlock(&queue->lock);
    return item;
}