#define _GNU_SOURCE
#include "BlockingQueue.h"
#include <malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

typedef struct {
    char *key;
    int value;
} KeyValue;

BlockingQueue queue;
int count = 10;

void *consumer(void *p) {
    pthread_attr_t attr;
    size_t stackSize;
    pthread_getattr_np(pthread_self(), &attr);
    pthread_attr_getstacksize(&attr, &stackSize);
    printf("Consumer stack: %ld\n", stackSize);

    for (int i = 0; i < count; i++) {
        KeyValue *d = takeOutFrom(&queue);
        printf("Consumer took %s, value %d\n", d->key, d->value);
        free(d->key);
        free(d);
    }
    return 0;
}
void *producer(void *p) {
    pthread_attr_t attr;
    size_t stackSize;
    pthread_getattr_np(pthread_self(), &attr);
    pthread_attr_getstacksize(&attr, &stackSize);
    printf("Producer stack: %ld\n", stackSize);

    for (int i = 0; i < count; i++) {
        char *key = malloc(10);
        sprintf(key, "Key: %d", i);
        KeyValue *d = malloc(sizeof(KeyValue));
        d->value = i;
        d->key = key;
        printf("Producer added %s, value %d\n", d->key, d->value);
        putInto(&queue, d);
        sleep(1);
    }
    return 0;
}

int main() {
    queue.capacity = 10;
    queue.count = 0;
    pthread_mutex_init(&queue.lock, 0);
    pthread_cond_init(&queue.condition, 0);
    queue.items = malloc(queue.capacity * sizeof(void *));

    pthread_attr_t attr;
    size_t stackSize = 1024;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, stackSize); //does it have any effect when it's less than 8m?

    pthread_t t1, t2;
    pthread_create(&t1, &attr, consumer, 0);
    pthread_create(&t2, &attr, producer, 0);

    pthread_join(t1, 0);
    pthread_join(t2, 0);

    free(queue.items);
    pthread_mutex_destroy(&queue.lock);
    pthread_cond_destroy(&queue.condition);
    return 0;
}