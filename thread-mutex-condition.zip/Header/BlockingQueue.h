#pragma once
#include <pthread.h>

typedef struct {
    int capacity, count;
    void *items;
    pthread_mutex_t lock;
    pthread_cond_t condition;
    unsigned char isWaiting;
} BlockingQueue;

void putInto(BlockingQueue *, void *);
void *takeOutFrom(BlockingQueue *);