#include <gtk/gtk.h>

static void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(window, "Window");
    gtk_window_set_default_size(window, 200, 200);
    gtk_widget_show(window);
}

int main(int argc, char **argv) {
    GtkApplication *app = gtk_application_new("why.doted.id", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", activate, NULL);
    int status = g_application_run(app, argc, argv);
    g_object_unref(app);
    return status;
}